INSERT INTO CATEGORY (category_name) VALUES('Mobile'),('Pants'),('Shirt');
INSERT INTO BRAND (brand_name) VALUES('Samsung'),('Allen Solly'),('Lee Cooper');
INSERT INTO SUPPLIER (supplier_name) VALUES('Vision Start'),('Flash Start Commerce'),('Flash Tech Retail');
INSERT INTO PRODUCTS (product_name, color, product_size,  category_id, supplier_id, brand_id, sku, description, price) VALUES
                               ('Samsung Galaxy A50', 'Black', '5.0', 1, 1, 1, 'SG-A50-MBL-BLK-5', 'Samsung Galaxy A50(Blue, 64 GB)', 5000),
                               ('Samsung Galaxy M30', 'Black', '5.5', 1, 3, 1, 'SG-A30-MBL-BLK-5', 'Samsung Galaxy M30(Black, 64 GB)', 5000),
                               ('Triper', 'Purple','M', 3, 2, 2,'TP-MSC-SHT-PUR-39', 'Men Stripped Casual', 1000),
                               ('Tripper', 'Black','32', 2, 3, 3, 'TP-MSC-PNT-BLK-32', 'Solid Men Black', 2000);

