DROP TABLE IF EXISTS SUPPLIER;
CREATE TABLE SUPPLIER (
  supplier_id INT AUTO_INCREMENT  PRIMARY KEY,
  supplier_name VARCHAR(250)
);

DROP TABLE IF EXISTS BRAND;
CREATE TABLE BRAND (
  brand_id INT AUTO_INCREMENT  PRIMARY KEY,
  brand_name VARCHAR(250)
);

DROP TABLE IF EXISTS CATEGORY;
CREATE TABLE CATEGORY (
  category_id INT AUTO_INCREMENT  PRIMARY KEY,
  category_name VARCHAR(250) NOT NULL
);

DROP TABLE IF EXISTS CATEGORY_PROPERTIES;
CREATE TABLE CATEGORY_PROPERTIES (
  property_id INT AUTO_INCREMENT  PRIMARY KEY,
  property_name VARCHAR(250) NOT NULL
);

DROP TABLE IF EXISTS PRODUCTS;
CREATE TABLE PRODUCTS (
  product_id INT AUTO_INCREMENT  PRIMARY KEY,
  category_id INT,
  supplier_id INT,
  brand_id INT,
  product_name VARCHAR(250) NOT NULL,
  sku VARCHAR(20) NOT NULL,
  color VARCHAR(10) NOT NULL,
  product_size VARCHAR(10),
  price INT,
  description VARCHAR(250) DEFAULT NULL,
  foreign key (category_id) references CATEGORY(category_id),
  foreign key (supplier_id) references SUPPLIER(supplier_id),
  foreign key (brand_id) references BRAND(brand_id)
);


DROP TABLE IF EXISTS PRODUCTS_ATTRIBUTES;
CREATE TABLE PRODUCTS_ATTRIBUTES (
  attribute_id INT AUTO_INCREMENT  PRIMARY KEY,
  product_id INT NOT NULL,
  attribute_name VARCHAR(250),
  attribute_value VARCHAR(250) NOT NULL,
  foreign key (product_id) references PRODUCTS(product_id)
);