package com.xyz.b2c.service;

import com.xyz.b2c.model.Product;
import com.xyz.b2c.model.Products;

public interface ProductSearchService {

    Products getProductsByCategoryAndColor(String category, String color);
    Products getProductsByCategoryAndSize(String category, String size);
    Product getProductsBySKU(String sku);
    Products getProductsByCategoryAndBrand(String category, String brand);
    Products getProductsBySeller(String seller);
    Products getProductsByCategoryAndPriceRange(String category, int from, int to);
}
