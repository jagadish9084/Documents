package com.xyz.b2c.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/*
@Entity
@Table(name = "PRODUCTS")*/
public class ProductEntity {

    @Id
    private Long id;

    @Column(name = "name")
    private String firstName;

    @Column(name = "description")
    private String description;

   /* @Column(name = "category_id", nullable = false, length = 200)
    private String category;*/

}
