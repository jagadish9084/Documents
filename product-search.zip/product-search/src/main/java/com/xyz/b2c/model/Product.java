package com.xyz.b2c.model;

import com.xyz.b2c.util.ReflectionBuilder;

public class Product {
    private int id;
    private String name;
    private String sku;
    private String description;
    private Brand brand;
    private int price;
    private Category category;
    private Supplier supplier;
    private String color;
    private String size;

    public interface ProductBuilder {
        ProductBuilder withId(int id);
        ProductBuilder withName(String name);
        ProductBuilder withSku(String sku);
        ProductBuilder withDescription(String description);
        ProductBuilder withBrand(Brand brand);
        ProductBuilder withPrice(int price);
        ProductBuilder withCategory(Category category);
        ProductBuilder withSupplier(Supplier supplier);
        ProductBuilder withColor(String color);
        ProductBuilder withSize(String size);
        Product build();
    }

    public static ProductBuilder builder() {
        return ReflectionBuilder.builderFor(ProductBuilder.class);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSku() {
        return sku;
    }

    public String getDescription() {
        return description;
    }

    public Brand getBrand() {
        return brand;
    }

    public int getPrice() {
        return price;
    }

    public Category getCategory() {
        return category;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public String getColor() {
        return color;
    }

    public String getSize() {
        return size;
    }
}
