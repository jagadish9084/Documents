package com.xyz.b2c.model;

public class PriceRangeRequest {

    private String category;
    private int from;
    private int to;

    public String getCategory() {
        return category;
    }

    public int getFrom() {
        return from;
    }

    public int getTo() {
        return to;
    }
}
