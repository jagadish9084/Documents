package com.xyz.b2c.persistence.dao;

import com.xyz.b2c.model.Brand;
import com.xyz.b2c.model.Category;
import com.xyz.b2c.model.Product;
import com.xyz.b2c.model.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Repository
public class ProductSearchPersistence {

    public static final String PRODUCTS_BY_CATEGORY_COLOR = "" +
            "select distinct * from products p\n" +
            "    join CATEGORY ct on ct.category_id=p.category_id \n" +
            "    join SUPPLIER s on s.supplier_id=p.supplier_id\n" +
            "    join BRAND b on b.brand_id=p.brand_id\n" +
            "    where ct.category_name=? and p.color=?";

    public static final String PRODUCTS_BY_CATEGORY_SIZE = "" +
            "select distinct * from products p\n" +
            "    join CATEGORY ct on ct.category_id=p.category_id \n" +
            "    join SUPPLIER s on s.supplier_id=p.supplier_id\n" +
            "    join BRAND b on b.brand_id=p.brand_id\n" +
            "    where ct.category_name=? and p.product_size=?";

    public static final String PRODUCTS_BY_CATEGORY_SKU = "" +
            "select distinct * from products p\n" +
            "    join CATEGORY ct on ct.category_id=p.category_id \n" +
            "    join SUPPLIER s on s.supplier_id=p.supplier_id\n" +
            "    join BRAND b on b.brand_id=p.brand_id\n" +
            "    where p.sku=?";

    public static final String PRODUCTS_BY_CATEGORY_BRAND = "" +
            "select distinct * from products p\n" +
            "    join CATEGORY ct on ct.category_id=p.category_id \n" +
            "    join SUPPLIER s on s.supplier_id=p.supplier_id\n" +
            "    join BRAND b on b.brand_id=p.brand_id\n" +
            "    where ct.category_name=? and b.brand_name=?";

    public static final String PRODUCTS_BY_CATEGORY_SELLER = "" +
            "select distinct * from products p\n" +
            "    join CATEGORY ct on ct.category_id=p.category_id \n" +
            "    join SUPPLIER s on s.supplier_id=p.supplier_id\n" +
            "    join BRAND b on b.brand_id=p.brand_id\n" +
            "    where s.supplier_name=?";

    public static final String PRODUCTS_BY_CATEGORY_PRICE_RANGE = "" +
            "select distinct * from products p\n" +
            "    join CATEGORY ct on ct.category_id=p.category_id \n" +
            "    join SUPPLIER s on s.supplier_id=p.supplier_id\n" +
            "    join BRAND b on b.brand_id=p.brand_id\n" +
            "    where ct.category_name=? and p.price >= ? and p.price <=?";


    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Product> getProductByAttribute(String query, Map<Object, Class> filterAttributes) {
        return jdbcTemplate.query(query, productAttributeSetter(filterAttributes), productDetailsMapper());
    }

    private RowMapper<Product> productDetailsMapper() {
        return (rs, i) -> {
            //Category
            int categoryId = rs.getInt("category_id");
            String categoryName = rs.getString("category_name");
            Category category = Category.builder().withId(categoryId).withName(categoryName).build();


            //Brand
            int brandId = rs.getInt("brand_id");
            String brand_name = rs.getString("brand_name");
            Brand brand = Brand.builder().withBrandId(brandId).withBrandName(brand_name).build();

            //Supplier
            int supplierId = rs.getInt("supplier_id");
            String supplierName = rs.getString("supplier_name");
            Supplier supplier = Supplier.builder().withSupplierId(supplierId).withSupplierName(supplierName).build();

            //Product
            int productId = rs.getInt("product_id");
            String productName = rs.getString("product_name");
            String description = rs.getString("description");
            String color = rs.getString("color");
            String size = rs.getString("product_size");
            String sku = rs.getString("sku");
            int price = rs.getInt("price");
            return Product.builder()
                    .withId(productId)
                    .withName(productName)
                    .withDescription(description)
                    .withSku(sku)
                    .withBrand(brand)
                    .withCategory(category)
                    .withSupplier(supplier)
                    .withColor(color)
                    .withPrice(price)
                    .withSize(size)
                    .build();
        };
    }

    private PreparedStatementSetter productAttributeSetter(Map<Object, Class> attributeValue) {
        return preparedStatement -> {
            AtomicInteger counter = new AtomicInteger(0);
            attributeValue.forEach((key, value) -> {
                try {
                    if (Integer.class.equals(value)) {
                        preparedStatement.setInt(counter.incrementAndGet(), (Integer) key);
                    } else if (String.class.equals(value)) {
                        preparedStatement.setString(counter.incrementAndGet(), (String) key);
                    } else {
                        preparedStatement.setObject(counter.incrementAndGet(), key);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            });
        };
    }
}
