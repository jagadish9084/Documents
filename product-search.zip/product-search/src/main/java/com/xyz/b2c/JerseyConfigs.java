package com.xyz.b2c;

import com.xyz.b2c.api.impl.ProductCatalogSearchImpl;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

@Component
public class JerseyConfigs extends ResourceConfig {

    public JerseyConfigs() {
        register(ProductCatalogSearchImpl.class);
    }
}
