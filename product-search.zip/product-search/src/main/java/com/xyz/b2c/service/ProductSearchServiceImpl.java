package com.xyz.b2c.service;

import com.google.common.collect.ImmutableMap;
import com.xyz.b2c.model.Product;
import com.xyz.b2c.model.Products;
import com.xyz.b2c.persistence.dao.ProductSearchPersistence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.NotFoundException;
import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiFunction;

@Component
public class ProductSearchServiceImpl implements ProductSearchService {

    @Autowired
    ProductSearchPersistence productSearchPersistence;

    @Override
    public Products getProductsByCategoryAndColor(String category, String color) {
        Map<Object, Class> filterAttributes = ImmutableMap.of(category, String.class, color, String.class);
        return toProducts().apply(ProductSearchPersistence.PRODUCTS_BY_CATEGORY_COLOR, filterAttributes);
    }

    @Override
    public Products getProductsByCategoryAndSize(String category, String size) {
        Map<Object, Class> filterAttributes = ImmutableMap.of(category, String.class, size, String.class);
        return toProducts().apply(ProductSearchPersistence.PRODUCTS_BY_CATEGORY_SIZE, filterAttributes);
    }

    @Override
    public Product getProductsBySKU(String sku) {
        Map<Object, Class> filterAttributes = ImmutableMap.of(sku, String.class);
        List<Product> products = productSearchPersistence.getProductByAttribute(ProductSearchPersistence.PRODUCTS_BY_CATEGORY_SKU, filterAttributes);
        return Optional.ofNullable(products)
                .filter(pds -> !pds.isEmpty())
                .flatMap(pds -> pds.stream().findFirst())
                .orElseThrow(() -> new NotFoundException("Product could not found by given parameter"));
    }


    @Override
    public Products getProductsByCategoryAndBrand(String category, String brand) {
        Map<Object, Class> filterAttributes = ImmutableMap.of(category, String.class, brand, String.class);
        return toProducts().apply(ProductSearchPersistence.PRODUCTS_BY_CATEGORY_BRAND, filterAttributes);

    }

    @Override
    public Products getProductsBySeller(String seller) {
        Map<Object, Class> filterAttributes = ImmutableMap.of(seller, String.class);
        return toProducts().apply(ProductSearchPersistence.PRODUCTS_BY_CATEGORY_SELLER, filterAttributes);

    }

    @Override
    public Products getProductsByCategoryAndPriceRange(String category, int from, int to) {
        Map<Object, Class> filterAttributes = ImmutableMap.of(category, String.class, from, Integer.class, to, Integer.class);
        return toProducts().apply(ProductSearchPersistence.PRODUCTS_BY_CATEGORY_PRICE_RANGE, filterAttributes);

    }

    private BiFunction<String, Map<Object, Class>, Products> toProducts() {
        return (String sql, Map<Object, Class> attribute) ->
                Optional.ofNullable(productSearchPersistence.getProductByAttribute(sql, attribute))
                        .map(Products::new)
                        .orElseThrow(() -> new NotFoundException("Product could not found by given parameter"));
    }

}
