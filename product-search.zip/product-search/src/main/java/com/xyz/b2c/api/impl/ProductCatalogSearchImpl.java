package com.xyz.b2c.api.impl;

import com.xyz.b2c.api.ProductCatalogSearch;
import com.xyz.b2c.model.PriceRangeRequest;
import com.xyz.b2c.model.Product;
import com.xyz.b2c.model.Products;
import com.xyz.b2c.service.ProductSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProductCatalogSearchImpl implements ProductCatalogSearch {

    /*TODO
     *  1. Add logger
     *  2. Add swagger
     *  3. Refactor APIs to support product search with addition parameter without adding new APIs
     * */
    @Autowired
    private ProductSearchService productSearchService;

    @Override
    public Product getProductBySKU(String sku) {
        return productSearchService.getProductsBySKU(sku);
    }

    @Override
    public Products getProductByCategoryAndSize(String category, String size) {
        return productSearchService.getProductsByCategoryAndSize(category, size);
    }

    @Override
    public Products getProductBySuppliers(String supplier) {
        return productSearchService.getProductsBySeller(supplier);
    }

    @Override
    public Products getProductByCategoryAndColor(String category, String color) {
        return productSearchService.getProductsByCategoryAndColor(category, color);
    }

    @Override
    public Products getProductByCategoryAndBrand(String category, String brand) {
        return productSearchService.getProductsByCategoryAndBrand(category, brand);
    }

    @Override
    public Products getProductByCategoryAndPriceRange(PriceRangeRequest priceRangeRequest) {
        return productSearchService.getProductsByCategoryAndPriceRange(priceRangeRequest.getCategory(), priceRangeRequest.getFrom(), priceRangeRequest.getTo());
    }
}
