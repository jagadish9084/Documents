package com.xyz.b2c.api;

import com.xyz.b2c.model.PriceRangeRequest;
import com.xyz.b2c.model.Product;
import com.xyz.b2c.model.Products;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;

import javax.ws.rs.*;

@Path("/product")
@CrossOrigin
public interface ProductCatalogSearch {

    @GET
    @Path("/category/{category}/size/{size}")
    @Produces("application/json")
    Products getProductByCategoryAndSize(@PathParam("category") String category, @PathParam("size") String size);

    @GET
    @Path("/category/{category}/color/{color}")
    @Produces("application/json")
    Products getProductByCategoryAndColor(@PathParam("category") String category, @PathParam("color") String color);

    @GET
    @Path("/category/{category}/brand/{brand}")
    @Produces("application/json")
    Products getProductByCategoryAndBrand(@PathParam("category") String category, @PathParam("brand") String brand);

    @POST
    @Path("/priceRange")
    @Produces("application/json")
    Products getProductByCategoryAndPriceRange(@RequestBody PriceRangeRequest priceRangeRequest);

    @GET
    @Path("/supplier/{supplier}")
    @Produces("application/json")
    Products getProductBySuppliers(@PathParam("supplier") String supplier);

    @GET
    @Path("/sku/{sku}")
    @Produces("application/json")
    Product getProductBySKU(@PathParam("sku") String sku);
}
