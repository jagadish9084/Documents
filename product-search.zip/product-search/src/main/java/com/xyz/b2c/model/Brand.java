package com.xyz.b2c.model;


import com.xyz.b2c.util.ReflectionBuilder;

public class Brand {

    private int brandId;
    private String brandName;


    public interface BrandBuilder {
        BrandBuilder withBrandId(int brandId);
        BrandBuilder withBrandName(String brandName);
        Brand build();
    }

    public static BrandBuilder builder() {
        return ReflectionBuilder.builderFor(BrandBuilder.class);
    }


    public int getBrandId() {
        return brandId;
    }

    public String getBrandName() {
        return brandName;
    }

}
