package com.xyz.b2c.model;

import com.xyz.b2c.util.ReflectionBuilder;

import java.util.List;

public class Category {
    private int id;
    private String name;


    public interface CategoryBuilder {
        CategoryBuilder withId(int id);
        CategoryBuilder withName(String name);
        Category build();
    }

    public static CategoryBuilder builder() {
        return ReflectionBuilder.builderFor(CategoryBuilder.class);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
