package com.xyz.b2c.model;

import com.xyz.b2c.util.ReflectionBuilder;

public class Supplier {
    private int supplierId;
    private String supplierName;

    public interface SupplierBuilder {
        SupplierBuilder withSupplierId(int supplierId);
        SupplierBuilder withSupplierName(String supplierName);
        Supplier build();
    }

    public static SupplierBuilder builder() {
        return ReflectionBuilder.builderFor(SupplierBuilder.class);
    }

    public int getSupplierId() {
        return supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }
}
