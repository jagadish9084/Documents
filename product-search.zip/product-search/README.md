
 
#Product catalog search.
    Set of APIs to search products based on different parameter
    
    
# List of APIs
    1. Search by Category and Brand
        URL: http://localhost:8080/product/category/Mobile/brand/Samsung
        Request type: GET
        
    2. Search by Category and Size
        URL: http://localhost:8080/product/category/Mobile/size/5.0
        Request type: GET
        
    3. Search by Category and Color
        URL: http://localhost:8080/product/category/Mobile/color/Black
        Request type: GET
        
    4. Search Product by SKU
        URL: http://localhost:8080/product/sku/SG-A50-MBL-BLK-5
        Request type: GET
        
    5. Search by Category and Supplier
        URL: http://localhost:8080/product/supplier/Vision Start
        Request type: GET                        

    6. Search by Category and PriceRange
        URL: http://localhost:8080/product/priceRange
        Request type: POST
        Request Body: {"category": "MOBILE","from": 1000,"to":10000}                        

#How to Start this Project
    To start this project, run com.xyz.b2c.service.ProductSearchApplication which will start web service on port 8080 using embedded tomcat
    
#How to set up the test data:
    When you run the start the application, tables will be created and popultaed with sample data using below scripts:
    - resources/schema.sql
    - resources/data.sql
    
#How to connect to data base to see the data:

    You can connect to the database using h2 console
    Steps: 
        1. Open browser
        2. Enter below URL:
            http://localhost:8080/h2/login.jsp
        3. Enter below details:
            Driver class: org.h2.Driver
            Driver class: org.h2.Driver
            JDBC URL: jdbc:h2:mem:testdb
            User Name: sa
            Password : 

#TO DO

    - Refactor the code to incorporate additional products attributes
    - Refactor API to support different varient for the same product
    - Add Unit test
    - Add Behavioural test using Cukember
    
        