package com.scb.research.cadm.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.common.collect.Lists;
import com.scb.channels.foundation.util.ReflectionBuilder;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CadmUser {
    private String groupId;
    private String userId;
    private String userName;
    private String ctryCode;
    private String userRole;
    private String email;
    private String mobileIsdCode;
    private String mobileNum;
    private String secauthType;
    private String address;
    private List<Profile> profiles = new ArrayList<>();

    public String getGroupId() {
        return groupId;
    }

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public String getCtryCode() {
        return ctryCode;
    }

    public String getUserRole() {
        return userRole;
    }

    public String getEmail() {
        return email;
    }

    public String getMobileIsdCode() {
        return mobileIsdCode;
    }

    public String getMobileNum() {
        return mobileNum;
    }

    public String getSecauthType() {
        return secauthType;
    }

    public String getAddress() {
        return address;
    }

    public List<Profile> getProfiles() {
        return Lists.newArrayList(profiles);
    }

    public interface CadmUserBuilder {

        CadmUserBuilder groupId(String groupId);

        CadmUserBuilder userId(String userId);

        CadmUserBuilder userName(String userName);

        CadmUserBuilder ctryCode(String ctryCode);

        CadmUserBuilder userRole(String userRole);

        CadmUserBuilder email(String email);

        CadmUserBuilder mobileIsdCode(String mobileIsdCode);

        CadmUserBuilder mobileNum(String mobileNum);

        CadmUserBuilder secauthType(String secauthType);

        CadmUserBuilder address(String address);

        CadmUserBuilder profiles(List<Profile> profiles);

        CadmUser build();
    }

    public static CadmUserBuilder builder() {
        return ReflectionBuilder.builderFor(CadmUserBuilder.class);
    }


    @Override
    public String toString() {
        return "User{" +
                "userId='" + userId + '\'' +
                ", groupId='" + groupId + '\'' +
                ", userName='" + userName + '\'' +
                ", emailId='" + email + '\'' +
                '}';
    }
}
