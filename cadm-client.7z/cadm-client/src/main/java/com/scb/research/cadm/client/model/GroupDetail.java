package com.scb.research.cadm.client.model;

public class GroupDetail {

    private String groupId;
    private String grpName;
    private String shortName;
    private String addr1;
    private String ctryCode;
    private String grpContName;
    private String contactIsdCode;
    private String contactNum;
    private String grpOwnedCtryCode;
    private String s2bmarketSegment;
    private String scimarketSegment;
    private String applnMap;
    private String leId;
    private String subProfId;
    private String sciSegment;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGrpName() {
        return grpName;
    }

    public void setGrpName(String grpName) {
        this.grpName = grpName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getAddr1() {
        return addr1;
    }

    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }

    public String getCtryCode() {
        return ctryCode;
    }

    public void setCtryCode(String ctryCode) {
        this.ctryCode = ctryCode;
    }

    public String getGrpContName() {
        return grpContName;
    }

    public void setGrpContName(String grpContName) {
        this.grpContName = grpContName;
    }

    public String getContactIsdCode() {
        return contactIsdCode;
    }

    public void setContactIsdCode(String contactIsdCode) {
        this.contactIsdCode = contactIsdCode;
    }

    public String getContactNum() {
        return contactNum;
    }

    public void setContactNum(String contactNum) {
        this.contactNum = contactNum;
    }

    public String getGrpOwnedCtryCode() {
        return grpOwnedCtryCode;
    }

    public void setGrpOwnedCtryCode(String grpOwnedCtryCode) {
        this.grpOwnedCtryCode = grpOwnedCtryCode;
    }

    public String getS2bmarketSegment() {
        return s2bmarketSegment;
    }

    public void setS2bmarketSegment(String s2bmarketSegment) {
        this.s2bmarketSegment = s2bmarketSegment;
    }

    public String getScimarketSegment() {
        return scimarketSegment;
    }

    public void setScimarketSegment(String scimarketSegment) {
        this.scimarketSegment = scimarketSegment;
    }

    public String getApplnMap() {
        return applnMap;
    }

    public void setApplnMap(String applnMap) {
        this.applnMap = applnMap;
    }

    public String getLeId() {
        return leId;
    }

    public void setLeId(String leId) {
        this.leId = leId;
    }

    public String getSubProfId() {
        return subProfId;
    }

    public void setSubProfId(String subProfId) {
        this.subProfId = subProfId;
    }

    public String getSciSegment() {
        return sciSegment;
    }

    public void setSciSegment(String sciSegment) {
        this.sciSegment = sciSegment;
    }
}
