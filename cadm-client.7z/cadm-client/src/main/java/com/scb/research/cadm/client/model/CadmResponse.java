package com.scb.research.cadm.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import static com.scb.channels.foundation.util.ReflectionBuilder.builderFor;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CadmResponse {

    private String statusMessage;
    private String statusCode;
    private String requestId;
    private String groupId;
    private String userId;

    public interface CadmResponseBuilder {
        CadmResponseBuilder statusMessage(String statusMessage);

        CadmResponseBuilder statusCode(String statusCode);

        CadmResponseBuilder requestId(String requestId);

        CadmResponseBuilder groupId(String groupId);

        CadmResponseBuilder userId(String userId);

        CadmResponse build();
    }

    public static CadmResponseBuilder builder() {
        return builderFor(CadmResponseBuilder.class);
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getUserId() {
        return userId;
    }
}
