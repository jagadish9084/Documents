package com.scb.research.cadm.client;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.scb.research.cadm.client.model.CadmUser;
import com.scb.research.cadm.client.model.CadmResponse;
import com.scb.research.cadm.client.model.GroupDetail;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.HttpMethod;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import java.util.concurrent.TimeUnit;

public class CadmClientImpl implements CadmClient {

    private static final Logger logger = LoggerFactory.getLogger(CadmClientImpl.class);

    private static final String CREATE_USER_ENDPOINT = "/service/user";
    private static final String UPDATE_USER_ENDPOINT = "/service/modifyuser";
    private static final String DELETE_USER_ENDPOINT = "/service/user/{0}/{1}";
    private static final String QUERY_USER_ENDPOINT = "/service/user/{0}/{1}";
    private static final String QUERY_GROUP_ENDPOINT = "/service/group/{0}";
    private static final String POST_GROUP_DETAIL = "/service/group";
    private static final String GET_GROUP = POST_GROUP_DETAIL + "/";

    private String baseUrl;
    private String defaultGroupId;
    private final OkHttpClient client;

    private ObjectMapper objectMapper = new ObjectMapper().
            configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false).
            setSerializationInclusion(JsonInclude.Include.NON_NULL).
            configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true).
            configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).
            registerModule(new JavaTimeModule());

    @Override
    public CadmResponse createUser(CadmUser cadmUser) {
        logger.info("Creating User [{}]", cadmUser.toString());
        return doPost(cadmUser, baseUrl + CREATE_USER_ENDPOINT, CadmResponse.class);
    }

    @Override
    public CadmResponse deleteUser(String userId) {
        logger.info("Deleting User [{}]", userId);
        return doDelete(MessageFormat.format(baseUrl + QUERY_USER_ENDPOINT, userId, defaultGroupId), CadmResponse.class);
    }

    @Override
    public CadmResponse updateUser(CadmUser cadmUser) {
        return doPut(cadmUser, baseUrl + UPDATE_USER_ENDPOINT, CadmResponse.class);
    }

    @Override
    public CadmUser queryUser(String userId) {
        logger.info("Get User [{}]", userId);
        return doGet(MessageFormat.format(baseUrl + QUERY_USER_ENDPOINT, userId, defaultGroupId), CadmUser.class);
    }

    @Override
    public CadmResponse createGroup(GroupDetail groupDetail) {
        return doPost(groupDetail, baseUrl + POST_GROUP_DETAIL, CadmResponse.class);
    }

    @Override
    public CadmResponse deleteGroup(String groupId) {
        return doDelete(MessageFormat.format(baseUrl + QUERY_GROUP_ENDPOINT, groupId), CadmResponse.class);
    }

    @Override
    public GroupDetail queryGroup(String groupId) {
        return doGet(MessageFormat.format(baseUrl + QUERY_USER_ENDPOINT, groupId), GroupDetail.class);
    }


    public CadmClientImpl(String baseUrl, String groupId) {
        this.baseUrl = baseUrl;
        this.defaultGroupId = groupId;
        try {
            this.client = trustAllCerts(new OkHttpClient.Builder()).
                    connectTimeout(1000, TimeUnit.SECONDS).
                    readTimeout(1000, TimeUnit.SECONDS).
                    writeTimeout(1000, TimeUnit.SECONDS).
                    build();
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private <T> T doGet(String url, Class<T> type) {
        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();
        return execute(request, type);
    }

    private <T, R> T doPut(R detail, String url, Class<T> responseType) {
        try {
            Request request = new Request.Builder()
                    .url(url)
                    .method(HttpMethod.PUT,
                            RequestBody.create(
                                    okhttp3.MediaType.parse("application/json"),
                                    objectMapper.writeValueAsString(detail)))
                    .build();
            return execute(request, responseType);
        } catch (JsonProcessingException e) {
            logger.error("Error while deserializing an object ", e);
            throw new RuntimeException(e);
        }
    }

    private <T, R> T doPost(R detail, String url, Class<T> responseType) {
        try {
            Request request = new Request.Builder()
                    .url(url)
                    .method(HttpMethod.POST,
                            RequestBody.create(
                                    okhttp3.MediaType.parse("application/json"),
                                    objectMapper.writeValueAsString(detail)))
                    .build();
            return execute(request, responseType);
        } catch (JsonProcessingException e) {
            logger.error("Error while deserializing an object ", e);
            throw new RuntimeException(e);
        }
    }

    private <T> T execute(Request request, Class<T> type) {
        try (Response response = client.newCall(request).execute()) {
            int statusCode = response.code();
            ResponseBody body = response.body();
            logger.info("Response with Status code: " + statusCode);
            if (statusCode == 200) {
                if (body != null && body.contentLength() != 0) {
                    String bodyString = body.string();
                    logger.info("Body :" + bodyString);
                    return (T) objectMapper.readValue(bodyString, type);
                }
            }
            if (statusCode > 405) {
                logger.info("Reason for failure: " + (body != null ? body.string() : null));
                throw new RuntimeException("Failed to get details from CADM, Response code: [{}]" +
                        response.code() + " Response body: " + (body != null ? body.string() : null));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    private <T> T doDelete(String url, Class<T> type) {

        Request request = new Request.Builder()
                .url(url)
                .delete()
                .build();
        return execute(request, type);

    }

    private OkHttpClient.Builder trustAllCerts(OkHttpClient.Builder clientBuilder) throws NoSuchAlgorithmException, KeyManagementException {

        final TrustManager[] trustAllCertsManager = new TrustManager[]{new X509TrustManager() {
            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }

            @Override
            public void checkServerTrusted(final X509Certificate[] chain,
                                           final String authType) throws CertificateException {
            }

            @Override
            public void checkClientTrusted(final X509Certificate[] chain,
                                           final String authType) throws CertificateException {
            }
        }};

        SSLContext sslContext = SSLContext.getInstance("SSL");

        sslContext.init(null, trustAllCertsManager, new java.security.SecureRandom());
        clientBuilder.sslSocketFactory(sslContext.getSocketFactory(), (X509TrustManager) trustAllCertsManager[0]);

        HostnameVerifier hostnameVerifier = (hostname, session) -> {
            logger.info("Trusting host " + hostname + ".. should match " + baseUrl);
            return true;
        };

        clientBuilder.hostnameVerifier(hostnameVerifier);
        return clientBuilder;
    }
}
