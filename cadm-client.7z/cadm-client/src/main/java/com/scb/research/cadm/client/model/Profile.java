package com.scb.research.cadm.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.scb.channels.foundation.util.ReflectionBuilder;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Profile {
    private String profileId;
    private String profileRole;
    private List<FunctionalEntitlement> funcEntl = new ArrayList<>();
    private List<DataEntitlement> dataEntl = new ArrayList<>();

    public String getProfileId() {
        return profileId;
    }

    public String getProfileRole() {
        return profileRole;
    }

    public List<FunctionalEntitlement> getFuncEntl() {
        return newArrayList(funcEntl);
    }

    public List<DataEntitlement> getDataEntl() {
        return newArrayList(dataEntl);
    }

    public interface ProfileBuilder {
        ProfileBuilder profileId(String profileId);

        ProfileBuilder profileRole(String profileRole);

        ProfileBuilder funcEntl(List<FunctionalEntitlement> funcEntl);

        ProfileBuilder dataEntl(List<DataEntitlement> dataEntl);

        Profile build();
    }

    public static ProfileBuilder builder() {
        return ReflectionBuilder.builderFor(ProfileBuilder.class);
    }
}
