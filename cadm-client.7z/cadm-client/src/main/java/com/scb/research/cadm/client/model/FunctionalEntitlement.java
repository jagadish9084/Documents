package com.scb.research.cadm.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.scb.channels.foundation.util.ReflectionBuilder;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FunctionalEntitlement {

    private String prodCode;
    private String servCode;
    private String functionId;

    public String getProdCode() {
        return prodCode;
    }

    public String getServCode() {
        return servCode;
    }

    public String getFunctionId() {
        return functionId;
    }

    public interface FunctionalEntitlementBuilder{
        FunctionalEntitlementBuilder prodCode(String prodCode);
        FunctionalEntitlementBuilder servCode(String servCode);
        FunctionalEntitlementBuilder functionId(String functionId);
        FunctionalEntitlement build();
    }

    public static FunctionalEntitlementBuilder builder(){
        return ReflectionBuilder.builderFor(FunctionalEntitlementBuilder.class);
    }
}
