package com.scb.research.cadm.client;

import com.scb.research.cadm.client.model.CadmUser;
import com.scb.research.cadm.client.model.CadmResponse;
import com.scb.research.cadm.client.model.GroupDetail;

public interface CadmClient {

    CadmResponse createUser(CadmUser CadmUser);

    CadmResponse deleteUser(String userId);

    CadmResponse updateUser(CadmUser CadmUser);

    CadmUser queryUser(String userId);


    CadmResponse createGroup(GroupDetail groupDetail);

    CadmResponse deleteGroup(String groupId);

    GroupDetail queryGroup(String groupId);
}
