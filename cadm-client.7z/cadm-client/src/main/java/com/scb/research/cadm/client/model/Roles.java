package com.scb.research.cadm.client.model;


public enum Roles {

    Operator("DPRESEARCH", "O"),
    Authoriser("DPRESEARCH", "A"),
    Inquire("DPRESEARCH", "R");

    private final String id;
    private final String role;


    Roles(String id, String role) {
        this.id = id;
        this.role = role;
    }

    public String role() {
        return role;
    }

    public String id() {
        return id;
    }
}
