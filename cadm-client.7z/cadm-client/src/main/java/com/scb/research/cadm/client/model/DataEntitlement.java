package com.scb.research.cadm.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.scb.channels.foundation.util.ReflectionBuilder;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DataEntitlement {

    private String prodCode;
    private String servCode;
    private String dataType;
    private String datavalue1;

    public String getProdCode() {
        return prodCode;
    }

    public String getServCode() {
        return servCode;
    }

    public String getDataType() {
        return dataType;
    }

    public String getDatavalue1() {
        return datavalue1;
    }

    public interface DataEntitlementBuilder{
        DataEntitlementBuilder prodCode(String prodCode);
        DataEntitlementBuilder servCode(String servCode);
        DataEntitlementBuilder dataType(String dataType);
        DataEntitlementBuilder datavalue1(String datavalue1);
        DataEntitlement build();
    }

    public static DataEntitlementBuilder builder(){
        return ReflectionBuilder.builderFor(DataEntitlementBuilder.class);
    }


    public boolean isCorporationId() {
        return "CORPORATE-ID".equals(this.dataType);
    }
}
